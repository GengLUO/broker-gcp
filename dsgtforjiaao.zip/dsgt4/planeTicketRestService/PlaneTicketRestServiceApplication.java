package be.kuleuven.dsgt4.planeTicketRestService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaneTicketRestServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(PlaneTicketRestServiceApplication.class, args);
    }
}